// Server-only: free, official tender feeds that are read directly (no scraping credits, no AI).
// Each item gets a stable source-native ID so the same notice is never stored twice.

export type StructuredTender = {
  fingerprint: string;
  title: string;
  organization: string | null;
  category: string;
  summary: string | null;
  posted_date: string | null;
  deadline: string | null;
  address: string | null;
  phone: string | null;
  email: string | null;
  source_url: string;
};

const UA = "Mozilla/5.0 (compatible; EliphazTenderBot/1.0)";

const CATEGORY_RULES: [string, RegExp][] = [
  ["ሕክምና", /medic|health|hospital|pharma|drug|vaccin|laborator|clinic/i],
  ["ኮንስትራክሽን", /construct|road|bridge|building|rehabilit|civil work|water supply|irrigation|school block/i],
  ["ኤሌክትሪክ", /electric|solar|power|generator|transformer|energy/i],
  ["ካርጎ", /transport|freight|cargo|logistic|vehicle|tire|tyre|shipping/i],
  ["አይቲ", /\bit\b|software|computer|laptop|digital|ict|network|server|system develop/i],
  ["ቢሮ እቃ", /furniture|stationer|office suppl|printing|toner/i],
];

export function guessCategory(text: string) {
  return CATEGORY_RULES.find(([, re]) => re.test(text))?.[0] ?? "ሌላ";
}

const clean = (s: unknown) => {
  if (typeof s !== "string") return null;
  const v = s.replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
  return v || null;
};

const isoDay = (s: unknown) => (typeof s === "string" && /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : null);
const today = () => new Date().toISOString().slice(0, 10);

async function getText(url: string) {
  const res = await fetch(url, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(30000) });
  if (!res.ok) throw new Error(`Fetch failed [${res.status}] ${url}`);
  return res.text();
}

/** World Bank procurement notices API — open JSON, Ethiopia projects only. */
async function worldBank(): Promise<StructuredTender[]> {
  const fields = [
    "id", "notice_type", "bid_description", "project_name", "contact_organization", "contact_address",
    "contact_phone_no", "contact_email", "submission_date", "submission_deadline_date", "procurement_method_name",
  ].join(",");
  const url =
    "https://search.worldbank.org/api/v2/procnotices?format=json&project_ctry_name_exact=Ethiopia" +
    `&rows=60&srt=submission_date&order=desc&fl=${fields}`;
  type Notice = {
    id: string; notice_type?: string; bid_description?: string; project_name?: string;
    contact_organization?: string; contact_address?: string; contact_phone_no?: string; contact_email?: string;
    submission_date?: string; submission_deadline_date?: string; procurement_method_name?: string;
  };
  const data = JSON.parse(await getText(url)) as { procnotices?: Notice[] };
  const now = today();
  return (data.procnotices ?? [])
    .filter((n) => /bid|quotation|proposal|expression/i.test(n.notice_type ?? ""))
    .map((n) => {
      const title = clean(n.bid_description) ?? clean(n.project_name) ?? "";
      return {
        fingerprint: `worldbank:${n.id}`,
        title,
        organization: clean(n.contact_organization),
        category: guessCategory(`${title} ${n.project_name ?? ""}`),
        summary: [clean(n.notice_type), clean(n.project_name), clean(n.procurement_method_name)].filter(Boolean).join(" · ") || null,
        posted_date: isoDay(n.submission_date),
        deadline: isoDay(n.submission_deadline_date),
        address: clean(n.contact_address),
        phone: clean(n.contact_phone_no),
        email: clean(n.contact_email),
        source_url: `https://projects.worldbank.org/en/projects-operations/procurement-detail/${n.id}`,
      };
    })
    .filter((t) => t.title && (!t.deadline || t.deadline >= now));
}

const MONTHS: Record<string, string> = {
  jan: "01", feb: "02", mar: "03", apr: "04", may: "05", jun: "06",
  jul: "07", aug: "08", sep: "09", oct: "10", nov: "11", dec: "12",
};

/** "08-Oct-26" -> "2026-10-08" */
function undpDate(s: string | undefined) {
  const m = s?.match(/(\d{1,2})-([A-Za-z]{3})-(\d{2,4})/);
  const [, day = "", monName = "", yr = ""] = m ?? [];
  const mon = MONTHS[monName.toLowerCase()];
  if (!m || !mon) return null;
  const year = yr.length === 2 ? `20${yr}` : yr;
  return `${year}-${mon}-${day.padStart(2, "0")}`;
}

/** UNDP procurement notices for the Ethiopia country office. */
async function undp(): Promise<StructuredTender[]> {
  const base = "https://procurement-notices.undp.org/";
  const html = await getText(`${base}search.cfm?cur_country=ETH`);
  const now = today();
  const out: StructuredTender[] = [];
  const blocks = html.matchAll(/<a href="view_negotiation\.cfm\?nego_id=(\d+)"[^>]*>([\s\S]*?)<\/a>/g);
  for (const [, id, body = ""] of blocks) {
    const spans = [...body.matchAll(/<span>([\s\S]*?)<\/span>/g)].map((m) => clean(m[1]) ?? "");
    const [title, ref, office, process, deadline, posted] = spans;
    if (!title || !/ETHIOPIA/i.test(office ?? "")) continue;
    const dl = undpDate(deadline);
    if (dl && dl < now) continue;
    out.push({
      fingerprint: `undp:${id}`,
      title,
      organization: "UNDP Ethiopia",
      category: guessCategory(title),
      summary: [process, ref].filter(Boolean).join(" · ") || null,
      posted_date: undpDate(posted),
      deadline: dl,
      address: "Addis Ababa, Ethiopia",
      phone: null,
      email: null,
      source_url: `${base}view_negotiation.cfm?nego_id=${id}`,
    });
  }
  return out;
}

/** Returns a reader for sources that have an open feed, or null to fall back to scraping. */
export function structuredReader(url: string): (() => Promise<StructuredTender[]>) | null {
  const host = new URL(url).hostname;
  if (host.endsWith("worldbank.org")) return worldBank;
  if (host === "procurement-notices.undp.org") return undp;
  return null;
}

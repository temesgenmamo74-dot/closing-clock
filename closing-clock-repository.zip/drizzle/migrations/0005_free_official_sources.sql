-- Retire 2merkato (paywalled aggregator) and add free official feeds.
UPDATE public.sources SET active = false WHERE url ILIKE '%2merkato%' OR url ILIKE '%twomerkato%';
--> statement-breakpoint
INSERT INTO public.sources (name, url, kind)
SELECT v.name, v.url, 'web'
FROM (VALUES
  ('የዓለም ባንክ (World Bank) — ኢትዮጵያ', 'https://search.worldbank.org/api/v2/procnotices?project_ctry_name_exact=Ethiopia'),
  ('UNDP ኢትዮጵያ', 'https://procurement-notices.undp.org/search.cfm?cur_country=ETH')
) AS v(name, url)
WHERE NOT EXISTS (SELECT 1 FROM public.sources s WHERE s.url = v.url);
